package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Standard Spring Boot Test Class.
 * This test ensures that the Application Context loads correctly.
 */
@SpringBootTest
class Demo67ApplicationTests {

    @Test
    void contextLoads() {
        // This method will fail if the application context (Database, Beans, etc.) cannot start.
    }

}