package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;

/**
 * Main entry point for Wellness-Kart.
 * Excludes default error auto-configuration to support CustomErrorController.
 */
@SpringBootApplication(exclude = { ErrorMvcAutoConfiguration.class }) 
public class Demo67Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo67Application.class, args);
    }

}