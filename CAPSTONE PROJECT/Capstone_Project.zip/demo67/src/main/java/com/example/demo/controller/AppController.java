package com.example.demo.controller;

import com.example.demo.entity.Order;
import com.example.demo.entity.User;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class AppController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    // Directory where uploaded profile photos are stored
    private static String UPLOADED_FOLDER = "src/main/resources/static/images/";

    // --- 1. PAGE ROUTING ---

    @GetMapping("/")
    public String viewIndexPage(Model model) {
        return "index";
    }

    @GetMapping("/login")
    public String viewLoginPage() {
        return "login";
    }

    @GetMapping("/register")
    public String viewRegisterPage() {
        return "register";
    }

    @GetMapping("/cart")
    public String viewCartPage() {
        return "cart";
    }

    @GetMapping("/success")
    public String viewSuccessPage() {
        return "success";
    }

    // --- 2. AUTHENTICATION & PROFILE MANAGEMENT ---

    @PostMapping("/do_register")
    public String registerUser(@ModelAttribute User user, 
                               @RequestParam("profilePic") MultipartFile file,
                               Model model) { // Added Model to send error messages
        try {
            // 1. Handle Image Upload
            if (!file.isEmpty()) {
                byte[] bytes = file.getBytes();
                Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
                Files.write(path, bytes);
                user.setProfileImage(file.getOriginalFilename());
            } else {
                user.setProfileImage("user.png"); 
            }

            // 2. Save User (This might fail if email exists!)
            userRepository.save(user);
            
            return "redirect:/login"; // Success

        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            // This catches the "Duplicate Entry" error
            e.printStackTrace();
            model.addAttribute("error", "Username or Email already exists!");
            return "register"; // Stay on register page and show error

        } catch (IOException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error uploading image.");
            return "register";
        }
    }

    @PostMapping("/do_login")
    public String loginUser(@RequestParam("username") String username,
                            @RequestParam("password") String password,
                            HttpSession session, Model model) {
        Optional<User> user = userRepository.findByUsername(username);
        
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            // Store user object in session to track logged-in state across pages
            session.setAttribute("loggedInUser", user.get());
            return "redirect:/";
        }
        
        model.addAttribute("error", "Invalid Username or Password");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // Clear session data
        return "redirect:/login";
    }

    // --- 3. ORDER & SEARCH LOGIC ---

    @PostMapping("/place_order")
    public String placeOrder(@RequestParam("bottle") String bottle,
                             @RequestParam("fragrances") String fragrances,
                             @RequestParam("total") Double total,
                             HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";

        Order order = new Order();
        order.setUser(user);
        order.setBottleType(bottle);
        order.setFragrances(fragrances);
        order.setTotalAmount(total);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("Placed"); // Initial status

        orderRepository.save(order);
        return "redirect:/success";
    }

    @GetMapping("/order-history")
    public String viewOrderHistory(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";

        // Fetch user-specific orders sorted by newest first
        List<Order> orders = orderRepository.findByUserOrderByOrderDateDesc(user);
        model.addAttribute("orders", orders);
        return "order-history";
    }

    @GetMapping("/search")
    public String searchOrders(@RequestParam("query") String query, HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/login";

        List<Order> allOrders = orderRepository.findByUserOrderByOrderDateDesc(user);
        
        // Filter orders by bottle type or fragrance keywords
        List<Order> filteredOrders = allOrders.stream()
                .filter(o -> o.getBottleType().toLowerCase().contains(query.toLowerCase()) || 
                             o.getFragrances().toLowerCase().contains(query.toLowerCase()))
                .toList();

        model.addAttribute("orders", filteredOrders);
        model.addAttribute("searchQuery", query);
        return "order-history";
    }
}