package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Saves a user to the database.
     * Fixes the error in image_95b136.png by using getProfileImage().
     */
    public User save(User user) {
        // Change getProfilePhoto to getProfileImage
        if (user.getProfileImage() == null || user.getProfileImage().isEmpty()) {
            user.setProfileImage("user.png");
        }
        return userRepository.save(user);
    }

    /**
     * Finds a user by their unique username.
     */
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    /**
     * Retrieves all users for the Admin Directory.
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Deletes a user by ID (used by Admin Panel).
     */
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}