package com.example.demo.controller;

import com.example.demo.entity.Admin;
import com.example.demo.entity.Order;
import com.example.demo.entity.User;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public String showAdminLoginPage() {
        return "admin/login"; // returns templates/admin/login.html
    }

    @PostMapping("/do-login")
    public String processAdminLogin(@RequestParam("username") String username,
                                   @RequestParam("password") String password,
                                   HttpSession session, Model model) {
        
        Optional<Admin> admin = adminRepository.findByUsername(username);
        
        // Safety check to prevent NullPointer during login
        if (admin.isPresent() && admin.get().getPassword().equals(password)) {
            session.setAttribute("adminUser", admin.get());
            return "redirect:/admin/dashboard";
        }
        
        model.addAttribute("error", "Invalid Admin Access Credentials");
        return "admin/login";
    }

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        if (session.getAttribute("adminUser") == null) {
            return "redirect:/admin/login";
        }

        List<Order> allOrders = orderRepository.findAll();
        List<User> allUsers = userRepository.findAll();

        // FIXED: Added .filter(o -> o.getTotalAmount() != null) 
        // This is the most common cause of 500 errors in your dashboard!
        double totalRevenue = allOrders.stream()
                .filter(o -> o.getTotalAmount() != null) 
                .filter(o -> !"Cancelled".equalsIgnoreCase(o.getStatus()))
                .mapToDouble(Order::getTotalAmount)
                .sum();

        model.addAttribute("totalOrders", allOrders.size());
        model.addAttribute("totalUsers", allUsers.size());
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("recentOrders", allOrders);

        return "admin/dashboard"; 
    }

    @PostMapping("/update-status")
    public String updateOrderStatus(@RequestParam("orderId") Long orderId,
                                   @RequestParam("status") String status,
                                   HttpSession session) {
        if (session.getAttribute("adminUser") == null) return "redirect:/admin/login";

        Optional<Order> orderOpt = orderRepository.findById(orderId);
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            order.setStatus(status);
            orderRepository.save(order);
        }
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/users")
    public String listUsers(HttpSession session, Model model) {
        if (session.getAttribute("adminUser") == null) return "redirect:/admin/login";

        model.addAttribute("users", userRepository.findAll());
        return "admin/user-management"; //
    }

    @GetMapping("/delete-user/{id}")
    public String removeUser(@PathVariable("id") Long id, HttpSession session) {
        if (session.getAttribute("adminUser") == null) return "redirect:/admin/login";

        userRepository.deleteById(id);
        return "redirect:/admin/users";
    }

    @GetMapping("/logout")
    public String adminLogout(HttpSession session) {
        session.removeAttribute("adminUser");
        return "redirect:/admin/login";
    }
}