package com.example.demo.service; // FIX: Corrected package path

import com.example.demo.entity.Order;
import com.example.demo.entity.User;
import com.example.demo.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    /**
     * Saves a new order with 'Handover Cash' payment mode.
     * This fixes the 500 error during checkout.
     */
    public Order createOrder(User user, String bottle, String fragrances, Double total) {
        Order order = new Order();
        order.setUser(user); 
        order.setBottleType(bottle); 
        order.setFragrances(fragrances);
        order.setTotalAmount(total);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("Placed");
        
        // This method now exists because we updated Order.java
        order.setPaymentMode("Handover Cash"); 

        return orderRepository.save(order);
    }

    /**
     * Retrieves history for the logged-in user.
     */
    public List<Order> getUserOrderHistory(User user) {
        return orderRepository.findByUserOrderByOrderDateDesc(user);
    }

    /**
     * Updates order status for Admin Dashboard.
     */
    public void updateStatus(Long orderId, String newStatus) {
        orderRepository.findById(orderId).ifPresent(order -> {
            order.setStatus(newStatus);
            orderRepository.save(order);
        });
    }

    /**
     * Logic for Admin Business Overview stats.
     */
    public double calculateTotalRevenue() {
        return orderRepository.findAll().stream()
                .filter(o -> !"Cancelled".equalsIgnoreCase(o.getStatus()))
                .mapToDouble(Order::getTotalAmount)
                .sum();
    }
}