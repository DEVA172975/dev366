/**
 * WELLNESS-KART MASTER UI SCRIPT
 * Version: 1.0.0
 * Handles: Fragrance Wheel, Cart Logic, Animations, and Session Updates
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Global State
    const cart = {
        bottle: null,
        fragrances: {},
        total: 0
    };

    // 2. Fragrance Selection Logic
    const fragranceItems = document.querySelectorAll('.fragrance-item');
    const floatingBar = document.getElementById('floatingBar');
    const selectedFragrancesList = document.getElementById('selectedFragrancesList');
    const totalPriceDisplay = document.getElementById('totalPrice');

    fragranceItems.forEach(item => {
        const plusBtn = item.querySelector('.plus-btn');
        const minusBtn = item.querySelector('.minus-btn');
        const countSpan = item.querySelector('.count');
        const name = item.getAttribute('data-name');
        const price = parseFloat(item.getAttribute('data-price'));

        plusBtn.addEventListener('click', () => {
            if (!cart.fragrances[name]) cart.fragrances[name] = 0;
            cart.fragrances[name]++;
            updateUI(name, cart.fragrances[name], price, 'add');
        });

        minusBtn.addEventListener('click', () => {
            if (cart.fragrances[name] > 0) {
                cart.fragrances[name]--;
                updateUI(name, cart.fragrances[name], price, 'remove');
            }
        });

        // Wheel Rotation Animation
        item.addEventListener('mouseenter', () => {
            const img = item.querySelector('img');
            img.style.transform = 'rotate(15deg) scale(1.1)';
        });

        item.addEventListener('mouseleave', () => {
            const img = item.querySelector('img');
            img.style.transform = 'rotate(0deg) scale(1)';
        });
    });

    // 3. UI Update Engine
    function updateUI(name, count, price, action) {
        // Update Count Display
        const itemElement = document.querySelector(`.fragrance-item[data-name="${name}"]`);
        itemElement.querySelector('.count').innerText = count;

        // Update Total Price
        if (action === 'add') cart.total += price;
        else cart.total -= price;

        totalPriceDisplay.innerText = cart.total.toFixed(2);

        // Show/Hide Floating Bar
        if (cart.total > 0) {
            floatingBar.classList.add('active');
        } else {
            floatingBar.classList.remove('active');
        }

        renderSelectedList();
        animateBadge();
    }

    // 4. Render the small selection tags
    function renderSelectedList() {
        selectedFragrancesList.innerHTML = '';
        for (const [name, count] of Object.entries(cart.fragrances)) {
            if (count > 0) {
                const tag = document.createElement('span');
                tag.className = 'selection-tag';
                tag.innerHTML = `${name} x${count}`;
                selectedFragrancesList.appendChild(tag);
            }
        }
    }

    // 5. Cart Submission Logic
    window.prepareCheckout = function() {
        const bottleType = document.querySelector('.bottle-card.selected')?.getAttribute('data-type') || 'Standard';
        
        // Prepare data for form submission
        const fragranceString = Object.entries(cart.fragrances)
            .filter(([_, count]) => count > 0)
            .map(([name, count]) => `${name}(x${count})`)
            .join(', ');

        document.getElementById('hiddenBottle').value = bottleType;
        document.getElementById('hiddenFragrances').value = fragranceString;
        document.getElementById('hiddenTotal').value = cart.total;

        document.getElementById('checkoutForm').submit();
    };

    // 6. Visual Effects
    function animateBadge() {
        const cartIcon = document.querySelector('.cart-icon');
        cartIcon.classList.add('pulse');
        setTimeout(() => cartIcon.classList.remove('pulse'), 300);
    }
});

// Utility: CSS Injector for Animations
const style = document.createElement('style');
style.innerHTML = `
    .pulse { transform: scale(1.2); transition: 0.2s; }
    .selection-tag {
        background: rgba(255,255,255,0.2);
        padding: 4px 10px;
        border-radius: 20px;
        margin-right: 8px;
        font-size: 12px;
        border: 1px solid rgba(255,255,255,0.3);
    }
    .floating-bar.active { bottom: 30px; opacity: 1; visibility: visible; }
`;
document.head.appendChild(style);