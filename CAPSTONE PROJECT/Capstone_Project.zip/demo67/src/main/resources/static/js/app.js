/* ===============================
   GLOBAL STATE
================================ */
let selectedBottle = null;
let bottlePrice = 0;

let fragrances = {}; // { Rose: qty, Lavender: qty }
const FRAGRANCE_PRICE = 150;

/* ===============================
   BOTTLE SELECTION
================================ */
document.querySelectorAll(".bottle-card button").forEach(btn => {
    btn.addEventListener("click", function () {
        const card = this.closest(".bottle-card");
        const variant = card.dataset.variant;
        const price = parseInt(card.dataset.price);

        selectedBottle = variant;
        bottlePrice = price;

        // highlight selected bottle
        document.querySelectorAll(".bottle-card").forEach(c => c.classList.remove("active"));
        card.classList.add("active");

        calculateTotal();
    });
});

/* ===============================
   FRAGRANCE QUANTITY CONTROL
================================ */
document.querySelectorAll(".fragrance-card").forEach(card => {

    const name = card.dataset.name;
    const qtySpan = card.querySelector("span");
    const minus = card.querySelectorAll("button")[0];
    const plus = card.querySelectorAll("button")[1];

    fragrances[name] = 0;

    plus.addEventListener("click", () => {
        fragrances[name]++;
        qtySpan.innerText = fragrances[name];
        calculateTotal();
    });

    minus.addEventListener("click", () => {
        if (fragrances[name] > 0) {
            fragrances[name]--;
            qtySpan.innerText = fragrances[name];
            calculateTotal();
        }
    });
});

/* ===============================
   TOTAL CALCULATION
================================ */
function calculateTotal() {
    let fragranceTotal = 0;
    let fragranceCount = 0;

    for (let f in fragrances) {
        fragranceTotal += fragrances[f] * FRAGRANCE_PRICE;
        fragranceCount += fragrances[f];
    }

    const total = bottlePrice + fragranceTotal;

    const totalEl = document.getElementById("totalAmount");
    if (totalEl) totalEl.innerText = total;

    updateCartCount(fragranceCount);
    saveToSession(total);
}

/* ===============================
   CART COUNT
================================ */
function updateCartCount(fragranceCount) {
    const cartCount = document.getElementById("cartCount");
    if (cartCount) {
        let count = fragranceCount;
        if (selectedBottle) count += 1;
        cartCount.innerText = count;
    }
}

/* ===============================
   SESSION STORAGE
================================ */
function saveToSession(total) {
    if (!selectedBottle) return;

    const usernameEl = document.querySelector(".username-text");
    const username = usernameEl ? usernameEl.innerText : "";

    sessionStorage.setItem("orderData", JSON.stringify({
        username: username,
        bottleVariant: selectedBottle,
        bottlePrice: bottlePrice,
        fragrances: fragrances,
        fragrancePrice: FRAGRANCE_PRICE,
        totalAmount: total
    }));
}
